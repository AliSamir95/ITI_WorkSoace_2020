#ifndef ANGRY_H
#define ANGRY_H
extern void AngrySpeaker_Say(char* string,int length);
#endif