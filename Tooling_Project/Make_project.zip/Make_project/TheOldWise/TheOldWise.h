#ifndef OLD_WISE_H
#define OLD_WISE_H
typedef enum { 
  false, 
  true 
} bool;
extern bool TheOldWise_Validate(int input);
#endif