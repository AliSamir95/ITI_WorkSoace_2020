#include "MathGeek.h"
#include <stdio.h>
#include <stdlib.h>

int MathGeek_Add(int value1, int value2)
{
  return value1+value2;
}