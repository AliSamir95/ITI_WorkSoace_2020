#ifndef MATH_GEEK_H
#define MATH_GEEK_H
extern int MathGeek_Add(int value1, int value2);
#endif