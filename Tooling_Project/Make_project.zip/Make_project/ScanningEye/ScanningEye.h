#ifndef SCAN_EYE_H
#define SCAN_EYE_H
extern void ScanningEye_Scan(int* input);
#endif