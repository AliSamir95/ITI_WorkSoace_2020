#include "ScanningEye.h"
#include <stdio.h>
#include <stdlib.h>

void ScanningEye_Scan(int* input)
{ 
  printf("please insert a number from 0 to 99\n");
  scanf("%i",input);
}