#include "FastPrinter.h"
#include <stdio.h>
#include <stdlib.h>

void FastPrinter_Print(int value)
{
  printf("\nThe Result = %i\n",value);
}