#ifndef FAST_PRINTER_H
#define FAST_PRINTER_H
extern void FastPrinter_Print(int value);
#endif